# Appendix A — Reporter plasmid assembly methods

## A1. Design objective
Construct an IPTG-inducible GFP reporter plasmid with a lac-regulated
promoter/operator, RBS, SGFP2 coding sequence and terminator. The design
described in the coursework uses **PA1lacO-1**, **SGFP2** and
**BBa_B0015**, sourced from the supplementary material of Camsund et al.
(2014). The selected pSB4C5-I52002 backbone (GenBank EU496100.1) is
described as containing a pSC101 origin and chloramphenicol resistance.

The supplied `backbone-sequence.gb` record is 4,311 bp. The prepared
backbone fragment `GG_04_pSB4C5_backbone.gb` is 3,245 bp.
These are different stages/files, not contradictory measurements.

## A2. Restriction/ligation
**OpenCloning:** EcoRI/PstI digestion and ligation of a pSB4C5-derived
backbone with a reporter cassette. The supplied final circular plasmid
export `final-reporter-plasmid-RL.gb` is 4,177 bp.

**Benchling:** Virtual EcoRI/PstI digest followed by Digest and Ligate
Assembly Wizard; the coursework reports an approximately 4.2 kb circular
product from a ~3.2 kb backbone and 997 bp insert.

**Figures in coursework:** Figure 11 (OpenCloning map), Figure 12
(Benchling assembly history/map).

## A3. Golden Gate
**OpenCloning:** Four prepared blocks — backbone, PA1lacO-1 promoter,
RBS-SGFP2 region and BBa_B0015 terminator — with BsaI recognition
sites and designed compatible overhangs. The supplied final circular
plasmid export `final-reporter-plasmid-GG.gb` is 4,177 bp.

**Benchling:** The original backbone's internal restriction sites
complicated the planned assembly. The coursework describes use of a
different destination vector from the NEBridge Golden Gate Assembly Kit
(BsaI-HFv2), yielding an approximately 3.1 kb plasmid. Because the
backbone differs, this Benchling product should **not** be described as
sequence-identical to the 4,177 bp OpenCloning product.

**Figures in coursework:** Figure 13 (OpenCloning), Figure 14 (Benchling).

## A4. Gibson
**OpenCloning:** The coursework describes a 956 bp reporter cassette
and a 3,221 bp backbone, extended with 30 bp overlaps, and a minimum
homology setting of 20 bp. It reports a 4,177 bp circular product.
The supplied Gibson preparation exports are 986 bp and 3,251 bp,
respectively: the 30 bp extensions account for the difference in
fragment lengths. These two extended input lengths should not simply
be added to infer the final plasmid size because the designed overlaps
are not independent sequence in the assembled molecule.

**Benchling:** The coursework describes a virtual digest and Gibson
Assembly Wizard using a 3,251 bp backbone and 986 bp reporter fragment,
giving an approximately 4.2 kb circular plasmid.

**Figures in coursework:** Figure 15 (OpenCloning), Figure 16 (Benchling).

## A5. Comparison and conclusion
OpenCloning restriction/ligation and Golden Gate final exports are
identical at the nucleotide level after accounting for circular origin
rotation; see `SEQUENCE_COMPARISON.md`. The uploaded Gibson inputs
support the stated fragment lengths, but do not by themselves establish
identity of a final Gibson product with the other two final exports.

The Benchling Golden Gate route used a different destination backbone
and thus is not directly equivalent to the OpenCloning pSB4C5-based
final construct. The other Benchling outcomes are documented from the
coursework's assembly maps and history, rather than from uploaded
Benchling final sequence exports.

## A6. References
Camsund, D. et al. (2014). *Design and analysis of LacI-repressed
promoters and DNA-looping in a cyanobacterium*. Journal of Biological
Engineering, 8, article 4.
https://doi.org/10.1186/1754-1611-8-4

GenBank accession: EU496100.1 (pSB4C5-I52002 backbone as cited in
the coursework).

Software/workflow: OpenCloning and Benchling, as identified in the
coursework. Software-specific export dates and versions were not
provided in the uploaded materials.
