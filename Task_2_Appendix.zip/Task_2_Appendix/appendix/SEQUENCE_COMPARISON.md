# Appendix B — GenBank sequence checks

## B1. Final plasmid identity

| Check | Result |
|---|---|
| OpenCloning restriction/ligation final | `final-reporter-plasmid-RL.gb` |
| OpenCloning Golden Gate final | `final-reporter-plasmid-GG.gb` |
| Restriction/ligation length | 4,177 bp |
| Golden Gate length | 4,177 bp |
| Direct string equality | No (different circular starting coordinates) |
| Equality after circular rotation | **Yes — 100% nucleotide identity** |
| Circular offset (GG starts at RL zero-based position) | 18 bp |
| Compared bases | 4,177 of 4,177 |

The equality was checked by testing whether the full Golden Gate
sequence occurs within two concatenated copies of the restriction/
ligation sequence. This is a valid exact sequence check for two
circular sequences with the same orientation and length. It does not
imply their feature annotations are identical.

## B2. Supporting fragments

| File | Length (bp) |
|---|---:|
| `GG_01_promoter.gb` | 99 |
| `GG_02_RBS_SGFP2.gb` | 781 |
| `GG_03_terminator.gb` | 156 |
| `GG_04_pSB4C5_backbone.gb` | 3,245 |
| `Gibson_01_reporter_986bp.gb` | 986 |
| `Gibson_02_backbone_3251bp.gb` | 3,251 |
| `PA1lacO1_SGFP2_B0015_BioBrick_999bp.gb` | 999 |
| `PA1lacO1_SGFP2_B0015_cassette_956bp.gb` | 956 |
| `backbone-sequence.gb` | 4,311 |
| `final-reporter-plasmid-GG.gb` | 4,177 |
| `final-reporter-plasmid-RL.gb` | 4,177 |

The Gibson reporter and backbone fragments are 986 bp and 3,251 bp,
consistent with the reported 956 bp and 3,221 bp source fragments
after adding 30 bp to each prepared input.

## B3. Boundaries of verification

- This check directly verifies identity between the two uploaded
  **OpenCloning final** plasmid sequence files only.
- A final Gibson product sequence was not included in the uploaded
  GenBank files; no independent final-Gibson identity claim is made.
- Benchling final-product GenBank exports were not included in the
  uploaded archives. Their sizes and assembly routes are therefore
  reported from the coursework narrative and figure captions.
- Some GenBank feature-location/qualifier formatting causes parser
  warnings; the sequence-length and full-sequence comparison above
  operate on the nucleotide sequences and do not depend on those
  feature annotations.
