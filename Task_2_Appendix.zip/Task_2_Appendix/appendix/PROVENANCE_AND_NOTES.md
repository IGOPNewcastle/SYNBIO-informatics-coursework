# Appendix C — Provenance and documentation notes

## Inputs
1. The Task 2 narrative and captions for Figures 11–16 supplied in
   the coursework.
2. `Reporter_plasmid_sequences.zip` — source supplement documents and
   GenBank files.
3. `Re__Reporter_plasmid_sequences.zip` — Gibson fragment GenBank files.

All uploaded `.gb` and `.docx` contents have been preserved unchanged
in `sequences/` and `sources/`.

## Review status
Human review, partner verification and reruns are complete according
to the coursework team. They are not outstanding actions.

## AI assistance
ChatGPT assisted with structuring this appendix and independently
checking the two uploaded final GenBank nucleotide sequences. Routine
generic AI prompts or saved chats are not separately attached: the
coursework team reported no significant changes attributable to such
generic interactions. This does not negate the disclosed AI assistance
with documentation and sequence checking.

## Interpretation
The **100% sequence identity** conclusion is specific to the two
uploaded OpenCloning final plasmids. The reported Benchling Golden Gate
assembly deliberately used a different backbone, and the supplied
Gibson files contain fragments rather than a final circular export.

The appendix records the supplied evidence and makes no claim of
physical wet-lab assembly or experimental verification.
