# AI assistance and provenance

OpenAI ChatGPT assisted with Python implementation, debugging, mathematical interpretation, plot preparation, and documentation. The combined script's original header records AI-assisted implementation dated 2026-10-19. Human verification against the article and supplied MATLAB code remains necessary before making exact-replication claims.

For this GitHub package, the combined Python script was executed with seed 20261019 and 100 noise runs. Its assertions passed and its independent quadrature diagnostic was 6.636469151999336e-12 days. The code does not simulate individual birth–death trajectories, and no independent partner rerun is asserted.

The standalone Figure 1 script and earlier README notes were supplied as provenance. The older README described a distinct 20-curve, seed-20261016 run and is not the authoritative metadata for the generated files committed here. See `results/run_metadata.json` for actual versions and parameters.
