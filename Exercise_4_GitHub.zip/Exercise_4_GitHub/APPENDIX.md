# Appendix — Exercise 4: Reproduce immigration and extinction results

## Scope and biological question

Curtis et al. (2026) investigate whether a small microbial population establishes in a new environment or disappears through random birth and death events. This Python exercise reconstructs establishment probabilities from Figure 1, duration calculations inspired by supplementary Figures A1–A2, and parameter-noise sensitivity inspired by A3. The reproduction is **partial, mathematical and qualitative**, not an exact replication.

The central question is: **Can a newly introduced population reach target abundance `N` before stochastic extinction, and how do the birth–death imbalance and starting abundance affect its probability and expected duration?** The gambler’s-ruin state `i` lies between absorbing boundaries 0 (extinction) and `N` (establishment threshold). At each event, birth has probability `p`, death has probability `q`, `p+q=1`, and `α=q/p`. The motivation is immigration, but this selected calculation has no explicit continuing immigration term. The duration routines use `c=1/24`, interpreted as days in the plotted results, and mean inter-event time `c/i` at abundance `i`.

## Figure 1 — establishment probability

The hitting probability satisfies

\[
P_i=pP_{i+1}+qP_{i-1},\quad P_0=0,\quad P_N=1.
\]

Thus

\[
P_i=\begin{cases}\dfrac{1-\alpha^i}{1-\alpha^N},&\alpha\ne1,\\[4pt]\dfrac{i}{N},&\alpha=1.\end{cases}
\]

The implementation evaluates `log10(P)` stably to avoid underflow. For `i=1`, `α<1` and large `N`, `P₁≈1−α`. For `α>1` and `αᴺ≫1`, `log₁₀(P₁)≈log₁₀(α−1)−N log₁₀(α)`. Panel (c) uses `x=log₁₀ N`, yielding `log₁₀(P₁)≈log₁₀(α−1)−10ˣ log₁₀(α)`, which explains the accelerating decline.

![Figure 1 reproduction](results/figure1_reproduced.png)

**Figure 1.** Python reconstruction of establishment probability, panels (a) and (c), with panel (b) as an inset. For the ratio plot `i=1`, `N=10,000`; the inset stops at `α=1`, while the published inset continues into `α>1`. The apparent zero to the right of neutrality in a linear-scale inset is a plotting-resolution effect: for finite `N`, `P₁` is positive. Panel (c) uses `α=1.000025, 1.000050, 1.000075, 1.000100`; exact published sampling has not been independently verified.

**Neutral and boundary checks.** At `p=q=0.5`, `N=10,000`, `P₁=10⁻⁴`. At `N=10`, starting abundances `i=1,5,10` yield `Pᵢ=0.1,0.5,1`. These validate limiting and boundary cases, not point-by-point equivalence to the publication.

## Supplementary A1 and A2 — duration calculations

For the upward-step calculation, the recurrence is

\[
m_i=\frac{c}{ip}+\alpha m_{i-1},\qquad m_0=0.
\]

The cumulative values reconstruct a duration from one cell to a target abundance. This lower-boundary convention **must not** be interpreted as the unconditional time to reach `N` in an absorbing-at-zero process.

For extinction, the expected time satisfies

\[
T_i=\frac{c}{i}+pT_{i+1}+qT_{i-1},\qquad T_0=0.
\]

With `τᵢ=Tᵢ−Tᵢ₋₁` and `α>1`:

\[
\tau_1=-\frac{c}{p}\ln(1-1/\alpha),\qquad
\tau_{i+1}=\alpha\tau_i-\frac{c}{pi},\qquad
T_i=\sum_{k=1}^i\tau_k.
\]

Both calculations use `α=1.002`, `c=1/24`, and abundances 1–1,000.

| A1 upward-step duration | A2 extinction duration |
|---|---|
| ![A1](results/A1_growth.png) | ![A2](results/A2_extinction.png) |

**Figure 2.** Reconstructed upward-step (A1) and expected extinction (A2) durations. A2 also shows independent quadrature checks.

The extinction recurrence was checked against

\[
T_i=\frac{c}{p}\int_0^1\frac{(1-x^i)/(1-x)}{\alpha-x}\,dx.
\]

Across ten sampled abundances, the executed combined script reported a **maximum absolute discrepancy of 6.636469151999336 × 10⁻¹² days**. The script reports the diagnostic but does not implement a separate `np.allclose` assertion for this integral comparison.

## Supplementary A3 — noise comparison

The baseline is `q=0.5002`, `p=0.4998`, `c=1/24`, and starting abundances 1–1,000. For each curve, the combined script draws one `q′=0.5002+U(-0.0002,0.0002)`, sets `p′=1−q′`, and computes the **expected** extinction duration. Draws are restricted to `q′>0.5`, because the unbounded mean is not finite otherwise. The committed run uses **100 curves** and seed **20261019**. Earlier README notes describe a separate 20-curve run with seed 20261016; those are not the committed outputs.

![A3 parameter noise](results/A3_noise.png)

**Figure 3.** A3-inspired sensitivity reconstruction. Black: baseline. Pale red: different sampled parameters. Vertical axis is `log₁₀(expected extinction time in days)`.

The generated `A3_summary.csv` includes mean, sample standard deviation, and 2.5th/97.5th percentiles across **parameter draws**. These are not trajectory-level confidence intervals. The supplied MATLAB routine instead perturbs `p` by ±0.00025, uses its original `p` in the first increment and a perturbed probability later, and has its noise comparison plotting call commented out. Consequently the Python figure is a sensitivity illustration, **not an identical author-code implementation**. Both exhibit a qualitative spread increasing with starting abundance; exact uncertainty equivalence is unverified.

## Neutral finite-capacity comparison (A4)

At `p=q=0.5`, finite-target establishment probability is `i/N`, but the unbounded mean extinction duration diverges. The supplementary finite-capacity expression is evaluated for `K=10⁴` and `K=10¹⁶` using harmonic numbers.

![Neutral finite-capacity comparison](results/A4_neutral_capacity.png)

**Figure 4.** Neutral finite-capacity extinction calculation. The appendix boundary `τ_K=1/K` is retained as printed; its physical time units remain unresolved. This plot is an additional code comparison, not a claim of exact published-figure replication.

## Materials, evidence and status

| Material | What is supported | Remaining limitation |
|---|---|---|
| Figure 1 | Analytic trends and neutral/boundary tests | Published sampling and inset range not exactly matched |
| A1/A2 | Duration recurrences; A2 independently checked to ~6.64×10⁻¹² days at ten points | A1 boundary interpretation; not a full author-code equivalence test |
| A3 | Seeded parameter sensitivity and descriptive percentiles | Different perturbation and uncertainty protocols from MATLAB |
| A4 | Harmonic-number finite-capacity expression | Physical-unit interpretation of `τ_K=1/K` |
| Software | Python, NumPy, SciPy, Matplotlib | Read actual versions from `results/run_metadata.json` |
| Empirical Figure 3 | R workflow previously discussed | Not rerun; sequencing/reactor data not independently evaluated |
| Independent reproduction | Script checks executed in this package | No partner independent rerun recorded |
| AI provenance | ChatGPT assisted implementation, debugging, interpretation and documentation | Human review remains necessary |

## Reproduction command

```bash
python -m pip install -r requirements.txt
python code/assignment4_reproduce.py --out results --seed 20261019 --noise-runs 100
```

Outputs include PNGs, numeric CSVs, `run_metadata.json` and `limitations.txt`. Run-specific package versions are captured in the JSON file. The executed command completed with “All checks passed.” and reported the A2 quadrature discrepancy above. No stochastic individual-based trajectories are simulated by A3.

## Conclusion and limitations

The gambler’s-ruin establishment equation and neutral limit were checked, and the extinction-duration recurrence closely matched an independent integral. Figure 1 and A3 reproduce the principal qualitative patterns, but plotting choices, parameter sampling, noise construction, author-code conventions and missing empirical data prevent a claim of exact replication. Multiple ChatGPT-assisted revisions sought better visual correspondence; the present figures were retained because the underlying mathematical trends were consistent with the selected published findings. Different Python, MATLAB and R implementations may also affect numerical or plotting details, but these environment differences have **not been established as the cause** of the remaining discrepancies.

**Reference:** Curtis et al. (2026), “Probability, parameters, and duration of immigration and extinction in microbial communities,” *The ISME Journal* **20**, wrag195; supplementary appendices and supplied MATLAB routines.

**Repository URL:** To be added after publication. **Partner verification:** Not yet documented.
