# Exercise 4 — Reproducing immigration and extinction results

**Curtis et al. (2026), _The ISME Journal_ 20, wrag195.**  This is a **partial mathematical / qualitative reconstruction**, not a claim of identical reproduction of all the authors' computational results.

**Coursework archive:** [https://github.com/IGOPNewcastle/SYNBIO-informatics-coursework/blob/main/Exercise_4_GitHub.zip](https://github.com/IGOPNewcastle/SYNBIO-informatics-coursework/blob/main/Exercise_4_GitHub.zip)  
**Repository:** [https://github.com/IGOPNewcastle/SYNBIO-informatics-coursework](https://github.com/IGOPNewcastle/SYNBIO-informatics-coursework)  
**Report:** [`submission/Exercise_4_Final_Report.docx`](submission/Exercise_4_Final_Report.docx)  
**Detailed mathematical record:** [`appendix/APPENDIX.md`](appendix/APPENDIX.md)

> **Archive URL status:** This is the intended GitHub destination supplied for the coursework. The ZIP provided here must be uploaded/replaced at that path; inclusion of a URL does not prove the newest archive is already online.

## Final result and scientific findings

1. **Figure 1:** The probability of reaching target abundance `N` before extinction depends strongly on the death-to-birth ratio `α=q/p`. For equal probabilities, `P(i)=i/N`; tests at `N=10` for `i=1,5,10` give `0.1`, `0.5`, and `1.0`.
2. **Duration (supplementary A1–A2):** The recurrence calculates population-size-dependent durations. An independent integral check for A2 differed by **6.64e-12 days** at ten tested abundances.
3. **Noise (supplementary A3):** Small parameter changes generate increasing variation in expected extinction time with increasing initial abundance. The submitted generated results use **100 parameter draws, seed 20261019**. This is **not** a set of 100 independently simulated birth/death trajectories.
4. **Supplementary A4:** An additional finite-capacity, equal-birth/death calculation is retained as an auxiliary mathematical check, with a boundary-unit ambiguity clearly disclosed.

For side-by-side comparison with published targets and the interpretive discussion, see the Word report and appendix. **Matching trends do not establish pointwise identity to the published plots.**

## Which random seed and environment are authoritative?

The committed `results/` files belong to **one specific 100-draw run**:

| Item | Value |
|---|---|
| Seed | `20261019` |
| Noise parameter draws | `100` |
| A3 baseline | `q=0.5002`, `p=0.4998`, `c=1/24` |
| Perturbation | One `q` draw per curve from `0.5002 ± 0.0002`; `p=1-q` |
| Saved execution Python | `3.13.5` |
| NumPy | `2.3.5` |
| SciPy | `1.17.0` |
| Matplotlib | `3.10.8` |

The **earlier separate IDLE experiment** used 20 draws, seed `20261016`, Python `3.15.0`, NumPy `2.5.4`, Matplotlib `3.11.2`. Those earlier figures are **not** the files in `results/`. Do not mix their means, SDs or versions with the 100-draw dataset. For provenance see [`appendix/RUN_RECORD.md`](appendix/RUN_RECORD.md) and [`results/run_metadata.json`](results/run_metadata.json).

## How to run

From the unzipped `Exercise_4_GitHub_Final` folder:

```bash
python -m pip install -r requirements.txt
python code/assignment4_reproduce.py --out results --seed 20261019 --noise-runs 100
```

The command regenerates the figures, CSVs and execution metadata. Platform/library differences may lead to small numeric differences. The standalone Figure 1 scripts are retained for provenance, but the **combined script** is the authoritative generator for `results/`.

## Files in this archive

| Path | Purpose |
|---|---|
| `submission/Exercise_4_Final_Report.docx` | Final full four-page coursework report supplied by student |
| `code/assignment4_reproduce.py` | Main source code for the 100-draw reproducible results |
| `code/figure1_standalone.py` | Previous Figure 1 implementation |
| `code/figure1_user_corrected_original.py` | Uploaded corrected Figure 1 original, preserved |
| `results/*.png` | Figure 1, A1, A2, A3 and A4 plots |
| `results/*.csv` | Numerical curve data, sampled noise parameters and summary statistics |
| `results/run_metadata.json` | Actual saved execution parameters, checks and software versions |
| `appendix/APPENDIX.md` | Equations, boundary conditions, figure interpretation and differences from authors' code |
| `appendix/VALIDATION.md` | Computational sanity checks and numerical comparisons |
| `appendix/AI_ASSISTANCE.md` | AI contribution, code provenance and prompt-record limitations |
| `appendix/RUN_RECORD.md` | Clear reconciliation of the two distinct experiments |
| `MANIFEST_SHA256.txt` | File checksums to verify archive contents |

## Computational validation

The archived Python implementation includes numerical assertions, and the saved run metadata records the reported results of the computational checks. See [`appendix/VALIDATION.md`](appendix/VALIDATION.md).

## Critical limitations

- Figure 1 plotting samples, some limits and inset extent are not exactly matched to the source.
- The A3 implementation perturbs **q by ±0.0002**; the inspected MATLAB noise routine perturbs **p by ±0.00025**, with additional code differences. The stored A3 SD and percentiles are across parameter draws, not trajectory confidence intervals.
- The neutral finite-capacity appendix boundary term has a time-unit ambiguity.
- The empirical Figure 3 dataset workflow was inspected but not reproduced here.
- The report includes figures and source comparisons; reproduced curves are not evidence of a perfect author-code replication.

## AI use and citation

ChatGPT assisted with Python code, mathematical checks, debugging, interpretation and documentation. AI-generated portions are identified in source headers and [`appendix/AI_ASSISTANCE.md`](appendix/AI_ASSISTANCE.md). Routine generic AI exchanges were not archived separately because no significant additional changes were identified from those exchanges. Substantive AI-assisted code and work are disclosed in `appendix/AI_ASSISTANCE.md`.

**Citation:** Curtis et al. (2026). “Probability, parameters, and duration of immigration and extinction in microbial communities.” _The ISME Journal_ **20**, wrag195; supplementary appendices and supplied MATLAB routines.

## Review status

Human review, partner verification and independent rerun are complete, as confirmed by the coursework team. These are not listed as remaining tasks.
