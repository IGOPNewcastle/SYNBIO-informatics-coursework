# Computational sanity checks

## Computational checks documented by the uploaded code/results

| Check | Evidence | Status |
|---|---|---|
| Unbiased birth/death: `P_i=i/N` | Python assertions in combined script; `N=10`, `i=1,5,10` expected `0.1,0.5,1.0` | Passed in prior execution according to run record |
| Absorbing boundaries: `P_0=0`, `P_N=1` | Code assertions | Passed in prior execution |
| Small population and ratio near 1 | Code comparison with closed-form establishment result | Passed in prior execution |
| Extinction A2 recurrence/integral | `results/run_metadata.json` | Max abs difference `6.636469151999336e-12` days at 10 points |
| Growth/extinction monotonicity | Python assertions | Passed in prior execution |
| Finite A3 parameter sensitivity curves | Python assertions, sampled parameters and summary CSV | Passed in prior execution |
| Fixed-seed repeatability | Seed and parameters explicitly recorded; rerun with same command | Reproducible procedure documented |

## Human review and independent rerun

Human review, partner verification and independent rerun have been completed,
as confirmed by the coursework team. They are **not outstanding tasks**.
The computational checks above retain the numerical evidence available in
the saved code and metadata; no additional personal verification record is
required within this archive.
