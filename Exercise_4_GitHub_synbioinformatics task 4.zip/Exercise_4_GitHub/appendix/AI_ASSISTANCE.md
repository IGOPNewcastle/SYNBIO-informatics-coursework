# AI assistance and prompt record

ChatGPT was used for Python implementation, mathematical interpretation, debugging,
plotting, independent numerical comparisons and documentation. The main Python
program identifies AI-generated implementation in its source header.

## Prompts and saved chat

Routine, generic AI interactions were not separately added to a prompt archive:
no significant additional changes were identified from that generic use.
Consequently, no separate saved-chat transcript or generic-prompt collection is
included. This is a statement about record selection, **not** a claim that AI
made no contribution to the code or coursework.

The substantive AI-assisted work is identified above and in the code headers.
The figures, calculations and checks were subsequently reviewed and rerun by
the coursework team.

## Provenance of the submitted run

The results in `../results/` correspond to the 100-draw run, seed `20261019`.
The earlier 20-draw IDLE experiment, seed `20261016`, is a distinct exploratory
run and is not used to describe the submitted figures.
