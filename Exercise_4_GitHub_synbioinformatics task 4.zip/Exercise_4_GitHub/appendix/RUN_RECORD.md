# Reproducible run record and provenance

## Submitted generated figures/CSVs: 100-draw combined Python run

- Main program: `code/assignment4_reproduce.py`
- Command: `python code/assignment4_reproduce.py --out results --seed 20261019 --noise-runs 100`
- Seed: **20261019**; A3 parameter draws: **100**
- Stored execution environment: Python **3.13.5**, NumPy **2.3.5**, SciPy **1.17.0**, Matplotlib **3.10.8**.
- Parameters for A3: baseline `q=0.5002`, uniform `q` perturbation ±`0.0002`; `p=1-q`, `c=1/24` days and abundance `1..1000`.
- Additional A1/A2 parameter set: `q/p=1.002`; Figure 1 panel a `i=1, N=10000`.
- Source of truth for executed settings: `results/run_metadata.json`.
- Source of truth for noise samples and uncertainty summaries: `results/A3_noise_draws.csv`, `results/A3_summary.csv`.

## Earlier IDLE exploratory run (separate; *not* the saved 100-draw data)

- 20 noise curves, seed **20261016**; earlier Windows IDLE session.
- Python **3.15.0**, NumPy **2.5.4**, Matplotlib **3.11.2**.
- One uniform perturbation to `p` of ±`0.0002` per curve.
- The earlier scripts/figures must not be identified as outputs of the 100-draw run or used to derive its statistical summaries.

## Independent checks and known uncertainty

The combined Python program checks neutral probability, boundary values, increasing durations and finite A3 outputs. At ten checked abundances the A2 integral vs recurrence diagnostic reports maximum absolute difference **6.636469151999336e-12 days**. The original 100-draw package reports `All checks passed.`; reproducibility requires rerunning the command on the target computer. These checks validate the implementation internally, not full identity to all author MATLAB calculations.

Noise A3 SD is the **sample standard deviation across sampled parameter values**; 2.5% and 97.5% columns are across-parameter empirical quantiles, not confidence intervals for a finite-sample simulated trajectory mean.
