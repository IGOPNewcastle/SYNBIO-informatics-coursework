
import math
import numpy as np
import matplotlib.pyplot as plt

# ============================================================
# ASSIGNMENT 4 - REPRODUCING FIGURE 1
# Curtis et al. (2026)
# Probability, parameters, and duration of immigration
# and extinction in microbial communities
#
# Python implementation assisted by ChatGPT
# ============================================================

# MODEL PARAMETERS
# Initial population: one individual
# Target population for Panel (a): 10,000 individuals

i = 1
N = 10_000


# ============================================================
# 1. PROBABILITY EQUATION
# ============================================================

def log10_probability(i, N, alpha):
    """
    Calculate log10 of the probability of reaching
    abundance N before extinction at zero.

    i     = starting abundance
    N     = target abundance
    alpha = q/p, ratio of death to birth probabilities
    """

    if N < 1 or i < 0 or i > N:
        raise ValueError("Require N >= 1 and 0 <= i <= N")

    if alpha <= 0:
        raise ValueError("alpha must be positive")

    # Boundary conditions
    if i == 0:
        return float("-inf")

    if i == N:
        return 0.0

    # Equal birth and death probabilities
    if abs(alpha - 1.0) < 1e-12:
        return math.log10(i / N)

    # Stable logarithmic calculation
    x = math.log(alpha)

    def log_abs_expm1(z):
        if z > 0:
            return z + math.log1p(-math.exp(-z))
        return math.log(-math.expm1(z))

    return (
        log_abs_expm1(i * x)
        - log_abs_expm1(N * x)
    ) / math.log(10)


# ============================================================
# 2. FIGURE 1(a)
# Probability versus death-to-birth ratio
# ============================================================

alpha_a = np.linspace(0.90, 1.05, 1200)

logp_a = np.array([
    log10_probability(i, N, alpha)
    for alpha in alpha_a
])


# ============================================================
# 3. FIGURE 1(b)
# Linear probability inset
# ============================================================

alpha_b = np.linspace(0.90, 1.00, 500)

prob_b = np.array([
    10 ** log10_probability(i, N, alpha)
    for alpha in alpha_b
])


# ============================================================
# 4. FIGURE 1(c)
# Probability versus log10 population abundance
# ============================================================

# Ratios shown approximately in the published colour legend.
# Verify exact values against the original figure/code.

ratios_c = [
    1.000025,
    1.000050,
    1.000075,
    1.000100
]

# Target population sizes from 10^1 to 10^8
logN_values = np.linspace(1, 8, 150)

targets_c = np.unique(
    np.logspace(1, 8, 150).astype(int)
)

log_targets = np.log10(targets_c)


# ============================================================
# 5. CREATE THE FIGURE
# ============================================================

fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))


# ---------------- PANEL (a) ----------------

axes[0].plot(
    alpha_a,
    logp_a,
    color="black",
    linewidth=2.5
)

axes[0].axvline(
    x=1,
    color="black",
    linestyle=":",
    linewidth=1
)

axes[0].set_xlabel(
    "Ratio of deaths to births, q/p"
)

axes[0].set_ylabel(
    "log10(P), probability of reaching 10^4"
)

axes[0].set_title(
    "(a) Establishment probability"
)

axes[0].set_xlim(0.90, 1.05)
axes[0].set_ylim(-180, 5)
axes[0].grid(True, alpha=0.4)


# ---------------- PANEL (b) INSET ----------------

inset = axes[0].inset_axes(
    [0.13, 0.12, 0.45, 0.32]
)

inset.plot(
    alpha_b,
    prob_b,
    color="black",
    linewidth=2
)

inset.set_xlabel(
    "q/p",
    fontsize=8
)

inset.set_ylabel(
    "Probability",
    fontsize=8
)

inset.set_xlim(0.90, 1.00)
inset.set_ylim(0, 0.11)
inset.tick_params(labelsize=7)
inset.grid(True, alpha=0.4)


# ---------------- PANEL (c) ----------------

for alpha in ratios_c:

    logp_c = np.array([
        log10_probability(1, int(n), alpha)
        for n in targets_c
    ])

    axes[1].plot(
        log_targets,
        logp_c,
        marker="o",
        markersize=2.5,
        linestyle="none",
        label=f"{alpha:.6f}"
    )


axes[1].set_xlabel(
    "log10(Population size, N)"
)

axes[1].set_ylabel(
    "log10(P)"
)

axes[1].set_title(
    "(c) Slightly disadvantaged populations"
)

axes[1].set_xlim(1, 8)
axes[1].set_ylim(-50, 2)

axes[1].legend(
    title="q/p",
    fontsize=8
)

axes[1].grid(True, alpha=0.4)


# ============================================================
# 6. SAVE AND DISPLAY
# ============================================================

plt.tight_layout()

plt.savefig(
    "task2_figure1_reproduced.png",
    dpi=300,
    bbox_inches="tight"
)

plt.show()


# ============================================================
# 7. VALIDATION TESTS
# ============================================================

neutral = 10 ** log10_probability(1, 10000, 1.0)

print("Neutral probability:", neutral)

assert math.isclose(
    neutral,
    0.0001,
    rel_tol=1e-10
)

assert log10_probability(10, 10, 1.0) == 0.0

assert log10_probability(0, 10, 1.0) == float("-inf")

print("All validation tests passed!")
print("Figure saved as task2_figure1_reproduced.png")
