#!/usr/bin/env python3
"""Assignment 4: Curtis et al. (2026), supplementary Appendices 1, 3, 4.

AI-generated implementation: OpenAI ChatGPT (GPT-6), 2026-10-19.
Verify against original author code before claiming exact reproduction.
Run: python assignment4_reproduce.py --out results --seed 20261019
Requires: numpy, scipy, matplotlib.
"""
import math
import argparse
import csv
import json
import platform
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import scipy
from scipy.integrate import quad
from scipy.special import digamma


def establishment(i, N, alpha):
    """Appendix 1, Eq. 1.4; boundaries P(0)=0, P(N)=1."""
    i = np.asarray(i, dtype=float)
    if np.isclose(alpha, 1.0, rtol=0, atol=1e-14):
        return i / N
    # expm1 avoids catastrophic cancellation near alpha=1.
    z = np.log(alpha)
    return (np.expm1(-i*z) / np.expm1(-N*z) * np.exp((i-N)*z)
            if z > 0 else np.expm1(i*z) / np.expm1(N*z))


def log10_probability(i, N, alpha):
    """
    Calculate log10 of the probability of reaching
    abundance N before extinction at zero.

    i     = starting abundance
    N     = target abundance
    alpha = q/p, ratio of death to birth probabilities
    """

    if N < 1 or i < 0 or i > N:
        raise ValueError("Require N >= 1 and 0 <= i <= N")

    if alpha <= 0:
        raise ValueError("alpha must be positive")

    # Boundary conditions
    if i == 0:
        return float("-inf")

    if i == N:
        return 0.0

    # Equal birth and death probabilities
    if abs(alpha - 1.0) < 1e-12:
        return math.log10(i / N)

    # Stable logarithmic calculation
    x = math.log(alpha)

    def log_abs_expm1(z):
        if z > 0:
            return z + math.log1p(-math.exp(-z))
        return math.log(-math.expm1(z))

    return (
        log_abs_expm1(i * x)
        - log_abs_expm1(N * x)
    ) / math.log(10)



def growth_time(nmax, p, dt):
    """Appendix 3, Eqs. 3.3-3.4, from one cell to n; m_0=0."""
    q = 1-p
    m = 0.0
    out = np.zeros(nmax + 1)
    for i in range(1, nmax):
        m = dt/(i*p) + (q/p)*m
        out[i+1] = out[i] + m
    return out


def extinction_time(nmax, p, dt):
    """Appendix 4, Eqs. 4.2-4.3, 4.7; valid only for q>p.

    Uses tau_1 = -(dt/p) log(1-1/alpha), then
    tau_{i+1} = alpha*tau_i - dt/(i*p).
    """
    q = 1-p
    alpha = q/p
    if alpha <= 1:
        raise ValueError('Unbounded mean extinction time requires q>p.')
    tau = -(dt/p)*np.log1p(-1/alpha)
    out = np.zeros(nmax+1)
    for i in range(1, nmax+1):
        out[i] = out[i-1]+tau
        if i < nmax:
            tau = alpha*tau-dt/(i*p)
            if tau <= 0:
                raise ArithmeticError('Unstable recurrence: increase numerical precision.')
    return out


def extinction_integral(i, p, dt):
    """Independent check: tau_k=(dt/p)*integral_0^1 x^(k-1)/(alpha-x) dx."""
    alpha = (1-p)/p
    if alpha <= 1:
        raise ValueError('Requires alpha>1')
    # Sum_{k=1}^i x^(k-1) = (1-x^i)/(1-x)
    value, _ = quad(lambda x: (-np.expm1(i*np.log(x)) / (1-x)) / (alpha-x)
                    if 0 < x < 1 else (i/(alpha-1) if x == 1 else 1/alpha),
                    0, 1, epsabs=1e-9, epsrel=1e-9, limit=300)
    return dt/p*value


def harmonic(n):
    """Exact H_n for integer n >= 0 via digamma."""
    return digamma(n+1)+np.euler_gamma


def neutral_capped_extinction(i, K, dt):
    """Appendix 4.1 Eq. 4.17, using the appendix's tau_K=1/K boundary.

    Note: 1/K is stated in the appendix; its physical time units need checking.
    """
    i = np.asarray(i, dtype=float)
    return 2*dt*i*(harmonic(K-1)-harmonic(i-1)) + i/K + 2*dt*(i-1)


def save_csv(path, header, columns):
    with open(path, 'w', newline='', encoding='utf-8') as f:
        w=csv.writer(f); w.writerow(header); w.writerows(zip(*columns))


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out', default='assignment4_results')
    parser.add_argument('--seed', type=int, default=20261019)
    parser.add_argument('--noise-runs', type=int, default=100)
    args=parser.parse_args()
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    dt=1/24  # time constant confirmed in supplied MATLAB script; plotted in days
    nmax=1000
    seed=args.seed
    rng=np.random.default_rng(seed)
    notes={
        'paper':'Curtis et al. (2026), The ISME Journal 20, wrag195',
        'ai_generated_code':True,
        'seed':seed,'noise_runs':args.noise_runs,'dt_days':dt,
        'dt_status':'c=1/24 appears in supplied MATLAB script; physical time interpretation follows plotted days axis',
        'A3_noise_status':'Assumed one uniform q perturbation per entire curve; author sampling protocol unverified',
        'A3_noise_range_q':[-0.0002,0.0002],
        'A3_baseline_q':0.5002,
        'A1_A2_alpha':1.002,
        'figure1_parameters_status':'Panels (a) and (c) adapted from user correction script; exact original panel parameters not fully verified',
        'A4_boundary_status':'Appendix 4.1 uses tau_K=1/K; units need independent checking',
        'versions':{'python':platform.python_version(),'numpy':np.__version__,
                    'scipy':scipy.__version__,'matplotlib':matplotlib.__version__}
    }
    # Figure 1: selected panels (a) and (c), using log probabilities
    # to avoid underflow for very small establishment probabilities.
    fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))
    alphas = np.linspace(0.90, 1.05, 1200)
    logp_a = np.array([log10_probability(1, 10000, a) for a in alphas])
    axes[0].plot(alphas, logp_a, color='black', linewidth=2.3)
    axes[0].axvline(1, color='black', linestyle=':', linewidth=1)
    axes[0].set(xlabel='Ratio of deaths to births, q/p',
                ylabel='log10(P), probability of reaching 10^4',
                title='(a) Establishment probability', xlim=(0.90,1.05), ylim=(-180,5))
    axes[0].grid(True, alpha=0.4)
    inset=axes[0].inset_axes([0.13,0.12,0.45,0.32])
    alpha_inset=np.linspace(0.90,1.00,500)
    inset.plot(alpha_inset,[10**log10_probability(1,10000,a) for a in alpha_inset],
               color='black',linewidth=1.8)
    inset.set(xlabel='q/p',ylabel='Probability',xlim=(0.90,1.00),ylim=(0,0.11))
    inset.tick_params(labelsize=7)
    inset.xaxis.label.set_size(8);inset.yaxis.label.set_size(8)
    inset.grid(True,alpha=0.4)
    ratios_c=[1.000025,1.000050,1.000075,1.000100]
    targets_c=np.unique(np.logspace(1,8,150).astype(int))
    for a in ratios_c:
        logp=np.array([log10_probability(1,int(n),a) for n in targets_c])
        axes[1].plot(np.log10(targets_c),logp,marker='o',markersize=2.5,
                     linestyle='none',label=f'{a:.6f}')
    axes[1].set(xlabel='log10(Population size, N)',ylabel='log10(P)',
                title='(c) Slightly disadvantaged populations',xlim=(1,8),ylim=(-50,2))
    axes[1].legend(title='q/p',fontsize=8)
    axes[1].grid(True,alpha=0.4)
    fig.tight_layout()
    fig.savefig(out/'figure1_reproduced.png',dpi=300,bbox_inches='tight')
    plt.close(fig)
    save_csv(out/'figure1_panel_a.csv',['q_over_p','log10_P'],[alphas,logp_a])
    save_csv(out/'figure1_panel_c.csv',
             ['N','log10_N']+[f'log10_P_q_over_p_{a:.6f}' for a in ratios_c],
             [targets_c,np.log10(targets_c)]+[
                 np.array([log10_probability(1,int(n),a) for n in targets_c])
                 for a in ratios_c])
    # A1 and A2: published ratio alpha=1.002; p+q=1.
    alpha=1.002;p=1/(1+alpha);q=1-p
    n=np.arange(1,nmax+1)
    grow=growth_time(nmax,p,dt)[1:]
    extinct=extinction_time(nmax,p,dt)[1:]
    for name, values, heading in [('A1_growth',grow,'A1: time from 1 to n'),
                                  ('A2_extinction',extinct,'A2: time from n to 0')]:
        fig,ax=plt.subplots(figsize=(7,4.5))
        valid=values>0
        ax.plot(n[valid],np.log10(values[valid]),color='firebrick',label='Recurrence')
        sample=np.array([1,2,5,10,25,50,100,200,500,1000])
        if name=='A2_extinction':
            independently=np.array([extinction_integral(int(i),p,dt) for i in sample])
            ax.plot(sample,np.log10(independently),'k.',label='Independent integral')
            maxerr=float(np.max(np.abs(independently-values[sample-1])))
            notes['A2_max_abs_error_days_at_sample_points']=maxerr
        ax.set(xlabel='Target n' if name=='A1_growth' else 'Initial abundance n',
               ylabel='log10(time in days)',title=f'{heading}; q/p={alpha}')
        ax.legend();fig.tight_layout();fig.savefig(out/f'{name}.png',dpi=180);plt.close(fig)
        save_csv(out/f'{name}.csv',['n','time_days'],[n,values])
    # A3: uniform q noise: one q draw for each complete trajectory.
    base_q=0.5002;base_p=1-base_q
    baseline=extinction_time(nmax,base_p,dt)[1:]
    curves=[];draws=[]
    for _ in range(args.noise_runs):
        # q<=0.5 makes the unbounded mean extinction time infinite: resample.
        # This conditioning is an additional modeling assumption, documented below.
        for trial in range(100000):
            qdraw=base_q+rng.uniform(-2e-4,2e-4)
            if qdraw>0.5:
                break
        else:
            raise RuntimeError('Could not draw q>0.5')
        draws.append(qdraw)
        curves.append(extinction_time(nmax,1-qdraw,dt)[1:])
    curves=np.asarray(curves)
    fig,ax=plt.subplots(figsize=(7,4.5))
    for y in curves:
        ax.plot(n,np.log10(y),color='lightcoral',alpha=0.13,linewidth=0.7)
    ax.plot(n,np.log10(baseline),color='black',linewidth=1.8,label='Baseline q=0.5002')
    ax.set(xlabel='Initial abundance n',ylabel='log10(time in days)',
           title='A3: uniform q noise (sampling assumption)',xlim=(0,1000))
    ax.legend();fig.tight_layout();fig.savefig(out/'A3_noise.png',dpi=180);plt.close(fig)
    save_csv(out/'A3_summary.csv',['n','baseline_days','mean_days','sd_days','p025_days','p975_days'],
             [n,baseline,curves.mean(axis=0),curves.std(axis=0,ddof=1),
              np.quantile(curves,.025,axis=0),np.quantile(curves,.975,axis=0)])
    save_csv(out/'A3_noise_draws.csv',['run','q'],[np.arange(len(draws)),draws])
    notes['A3_conditioning']='Draws restricted to q>0.5: otherwise infinite unbounded mean; verify author protocol'
    # A4: neutral p=q, finite carrying capacities.
    fig,ax=plt.subplots(figsize=(7,4.5))
    for K in [10**4,10**16]:
        t=neutral_capped_extinction(n,K,dt)
        ax.plot(n,np.log10(t),label=f'K={K:.0e}')
    ax.set(xlabel='Initial abundance i',ylabel='log10(time in days)',
           title='A4: neutral extinction with finite carrying capacity')
    ax.legend();fig.tight_layout();fig.savefig(out/'A4_neutral_capacity.png',dpi=180);plt.close(fig)
    # Unit tests and numeric diagnostics.
    assert np.isclose(log10_probability(1,10000,1.0),-4)
    assert np.isclose(log10_probability(1,10,1.0),-1)
    assert log10_probability(0,10,1.0)==float('-inf')
    assert log10_probability(10,10,1.0)==0.0
    assert np.isfinite(log10_probability(1,10000,1.05))
    assert np.allclose(establishment(np.array([0,1,5,10]),10,1),[0,.1,.5,1])
    assert np.isclose(establishment(1,10,1.0001),
                      (1-1.0001)/(1-1.0001**10),rtol=1e-7)
    assert np.all(np.diff(extinct)>0)
    assert np.all(np.diff(grow)>0)
    assert np.all(np.isfinite(curves))
    # Boundary K=1 gives time 1 according to the printed appendix convention.
    assert np.isclose(neutral_capped_extinction(np.array([1]),1,dt)[0],1)
    notes['tests']='Passed: neutral probabilities, small N, monotonic times, finite noise, K=1 boundary'
    with open(out/'run_metadata.json','w',encoding='utf-8') as f:
        json.dump(notes,f,indent=2)
    with open(out/'limitations.txt','w',encoding='utf-8') as f:
        f.write('Figure 1 panels (a,c) are reconstructed; exact published panel settings require confirmation.\n'
                'c=1/24 is explicitly present in supplied MATLAB script.\n'
                'A3 assumes a single uniform q draw per trajectory, with q>0.5.\n'
                'Appendix A3 does not specify all noise-sampling details.\n'
                'A4 follows the printed tau_K=1/K boundary; physical units require review.\n'
                'A1 has only recurrence in this script; A2 includes independent quadrature.\n'
                'Supplied MATLAB script inspected; no stochastic event simulations are claimed.\n')
    print('Saved results to:',out.resolve())
    print('A2 maximum independent-integral difference (days):',notes['A2_max_abs_error_days_at_sample_points'])
    print('All checks passed.')

if __name__=='__main__':
    main()
