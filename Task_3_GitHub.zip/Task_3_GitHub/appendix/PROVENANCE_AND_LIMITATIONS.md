# Appendix — Provenance, checks and limitations

## Data origin
The values in this package were transcribed from the Task 3 table and Python
arrays provided by the coursework author. The baseline was stated separately
and is **not** represented as an exported CSV observation. The 12 factorial
observations and Run13 are stored in `../data/PCR_simulation_runs.csv`.
No direct simulator export or run log was independently supplied here.

## Checks
- Four unique factorial conditions, three observations each.
- Means and sample SDs calculated independently from CSV by the Python script.
- Confirmation run excluded from factorial summary and error bars.
- Baseline excluded from factorial summary and CSV.
- Figure and summary CSV regenerated from the raw CSV.
- Human review, partner verification and reruns are reported as complete.

## Qualifications
- A zero observed SD for B/C/D yield is due to identical rounded input
  values; it does **not** establish absence of underlying variability.
- Three replicates per condition give limited uncertainty information.
- Non-parallel lines indicate a descriptive interaction pattern, not a
  statistically tested interaction.
- Yield and purity units follow the supplied coursework table.
- The simulator may not represent real-world effects such as primer
  mis-binding or primer-dimer formation; the exact Fellermann et al. (2019)
  source statement should be checked before quoting it as a verified claim.
- No random seed is relevant to the CSV analysis, since the observations
  are fixed and the script does not generate stochastic simulator results.

## AI assistance
ChatGPT assisted with packaging the supplied data, writing the analysis
script, and preparing Markdown documentation. No separate generic-prompt
archive is included; this is not a claim that AI made no contribution.
