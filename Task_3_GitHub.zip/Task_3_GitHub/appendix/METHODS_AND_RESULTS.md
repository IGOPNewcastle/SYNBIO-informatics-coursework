# Appendix — Task 3 methods, raw observations and results

## Experimental design
Four conditions combine annealing temperature (63°C and 73°C) and polymerase
quantity (1 U and 2 U). Three simulator observations per condition were
provided. Outcomes are yield in ng/µL and purity in percent, as labelled
in the supplied coursework table.

| Run | Temperature (°C) | Polymerase (U) | Yield (ng/µL) | Purity (%) |
|---|---:|---:|---:|---:|
| Baseline* | 68 | 1 | 0.1 | 10.8 |
| A1 | 63 | 1 | 0.2 | 11.5 |
| A2 | 63 | 1 | 0.1 | 11.2 |
| A3 | 63 | 1 | 0.1 | 11.4 |
| B1 | 63 | 2 | 0.2 | 12.4 |
| B2 | 63 | 2 | 0.2 | 12.7 |
| B3 | 63 | 2 | 0.2 | 12.3 |
| C1 | 73 | 1 | 0.1 | 10.2 |
| C2 | 73 | 1 | 0.1 | 10.5 |
| C3 | 73 | 1 | 0.1 | 10.1 |
| D1 | 73 | 2 | 0.1 | 11.0 |
| D2 | 73 | 2 | 0.1 | 11.4 |
| D3 | 73 | 2 | 0.1 | 10.9 |
| Run13 | 63 | 2 | 0.2 | 12.7 |

*Baseline was supplied in the user's original table and is not included in
the analysis CSV. Run13 is a separate confirmation observation, not a fourth
replicate in the factorial analysis.*

## Summary statistics
Means and **sample** standard deviations are calculated from the three
factorial observations per condition (`ddof=1`).

| Condition | Mean yield ± SD (ng/µL) | Mean purity ± SD (%) |
|---|---:|---:|
| A | 0.1333 ± 0.0577 | 11.3667 ± 0.1528 |
| B | 0.2000 ± 0.0000 | 12.4667 ± 0.2082 |
| C | 0.1000 ± 0.0000 | 10.2667 ± 0.2082 |
| D | 0.1000 ± 0.0000 | 11.1000 ± 0.2646 |

At 63°C, increasing polymerase from 1 U to 2 U increased mean yield by
0.0667 ng/µL. At 73°C, mean yield was unchanged at 0.1000 ng/µL.
Mean purity increased by 1.1000 percentage points at 63°C and
0.8333 percentage points at 73°C when polymerase was increased.

## Confirmation
Run13 at condition B gave 0.2 ng/µL yield and 12.7% purity.
Across B1, B2, B3 and Run13, the combined purity mean is 12.525%.
This four-run mean is **not** used in the original three-replicate
factorial plot or summary.

## Figure
`../figures/PCR_Interaction_Plot.png` shows mean ± sample SD, n=3 per
factorial condition. Non-parallel lines suggest a possible interaction,
especially for yield, but do not establish statistical significance.

## Interpretation
Among tested conditions, B (63°C, 2 U) has the highest mean yield and
purity. The confirmation run is consistent with this choice in the simulator.
The simulator is a simplified computational model, and these outputs should
not be represented as physical laboratory measurements.
