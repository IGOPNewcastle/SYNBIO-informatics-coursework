"""Task 3 PCR simulator: 2x2 factorial analysis, n=3 per condition.
Data are user-provided simulator outputs, not laboratory measurements.
The baseline and confirmation run are excluded from the factorial means/SDs.
"""
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data" / "PCR_simulation_runs.csv"
FIGURE = ROOT / "figures" / "PCR_Interaction_Plot.png"
SUMMARY = ROOT / "data" / "PCR_summary.csv"

with DATA.open(newline="", encoding="utf-8") as file:
    rows = list(csv.DictReader(file))

factorial = [row for row in rows if row["run_type"] == "factorial"]
assert len(factorial) == 12
temperature = np.array([63, 73])
results = {}
for temp in temperature:
    for units in (1, 2):
        subset = [r for r in factorial
                  if int(r["annealing_temperature_C"]) == temp
                  and int(r["polymerase_U"]) == units]
        assert len(subset) == 3
        y = np.array([float(r["yield_ng_per_uL"]) for r in subset])
        purity = np.array([float(r["purity_percent"]) for r in subset])
        results[(temp, units)] = {
            "yield_mean": y.mean(), "yield_sd": y.std(ddof=1),
            "purity_mean": purity.mean(), "purity_sd": purity.std(ddof=1)
        }

with SUMMARY.open("w", newline="", encoding="utf-8") as file:
    writer = csv.writer(file)
    writer.writerow(["condition","annealing_temperature_C","polymerase_U","n",
                     "yield_mean_ng_per_uL","yield_sample_sd_ng_per_uL",
                     "purity_mean_percent","purity_sample_sd_percent"])
    for condition, temp, units in [("A",63,1),("B",63,2),("C",73,1),("D",73,2)]:
        r = results[(temp, units)]
        writer.writerow([condition,temp,units,3,
                         f'{r["yield_mean"]:.6f}',f'{r["yield_sd"]:.6f}',
                         f'{r["purity_mean"]:.6f}',f'{r["purity_sd"]:.6f}'])

fig, axes = plt.subplots(1, 2, figsize=(12, 5))
for ax, metric, ylabel, title in [
    (axes[0], "yield", "Mean PCR yield (ng/µL)", "A. PCR Yield"),
    (axes[1], "purity", "Mean PCR purity (%)", "B. PCR Purity")
]:
    for units, color, marker, linestyle in [
        (1, "steelblue", "o", "-"), (2, "darkorange", "s", "--")
    ]:
        means = [results[(t, units)][metric + "_mean"] for t in temperature]
        sds = [results[(t, units)][metric + "_sd"] for t in temperature]
        ax.errorbar(temperature, means, yerr=sds, marker=marker,
                    linestyle=linestyle, linewidth=2, markersize=8,
                    capsize=5, color=color, label=f"{units} U polymerase")
    ax.set_xlabel("Annealing temperature (°C)")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    ax.set_xticks(temperature)
    ax.grid(alpha=0.3)
    ax.legend()

fig.suptitle("Interaction of Annealing Temperature and Polymerase Quantity",
             fontsize=13, fontweight="bold")
fig.tight_layout()
FIGURE.parent.mkdir(parents=True, exist_ok=True)
fig.savefig(FIGURE, dpi=300, bbox_inches="tight")
plt.close(fig)
print("Saved:", FIGURE)
print("Saved:", SUMMARY)
for key, r in results.items():
    print(key, {name: round(value, 4) for name, value in r.items()})
